from django.db import models
from produto.models import Produtos

class Saidas(models.Model):
    produto = models.ForeignKey(Produtos, on_delete=models.PROTECT)
    quantidade = models.IntegerField('Quantidade', default=0)
    preco = models.FloatField('Preço', default=0)
    
    def __str__(self) -> str:
        return self.produto
    # def __str__(self):
    #     return f"{self.produto} - {self.quantidade} unidades"
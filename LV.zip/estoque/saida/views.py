from django.shortcuts import render, redirect, get_object_or_404
from .models import Saidas
from .forms import SaidaForm
from produto.models import Produtos

def list_saida(request):
    saidas = Saidas.objects.all()
    template_name = 'list_saida.html'
    context = {'saidas': saidas}
    return render(request, template_name, context)

def new_saida(request):
    if request.method == 'POST':
        form = SaidaForm(request.POST)
        if form.is_valid():
            saida = form.save(commit=False)
            produto = saida.produto
            produto.quantidade -= saida.quantidade
            produto.save()
            saida.save()
            return redirect('saida:list_saida')
    else:
        template_name = 'new_saida.html'
        context = {
            'form': SaidaForm(),
        }
        return render(request, template_name, context)

def update_saida(request, pk):
    saida = get_object_or_404(Saidas, pk=pk)
    qt = saida.quantidade

    if request.method == 'POST':
        form = SaidaForm(request.POST, instance=saida)

        if form.is_valid():
            new_quantity = form.cleaned_data['quantidade']
            saida.produto.quantidade -= new_quantity - qt
            saida.produto.save()
            form.save()
            return redirect('saida:list_saida')

    else:
        form = SaidaForm(instance=saida)

    template_name = 'update_saida.html'
    context = {'form': form, 'pk': pk}
    return render(request, template_name, context)

def delete_saida(request, pk):
    saida = get_object_or_404(Saidas, pk=pk)
    produto = saida.produto
    saida.delete()

    return redirect('saida:list_saida')

# Create your views here.
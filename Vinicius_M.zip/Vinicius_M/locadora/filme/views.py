from django.shortcuts import render
from .models import filmes

def filme_list(request):
    f = filmes.objects.all()
    template_name = 'filme_list.html'
    context = {
        'f': f
    }

    return render(request, template_name, context)
# Create your views here.

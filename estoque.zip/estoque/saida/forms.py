from django import forms
from .models import Saidas

class SaidaForm(forms.ModelForm):
    class Meta:
        model = Saidas
        fields = ['produto', 'quantidade', 'preco']
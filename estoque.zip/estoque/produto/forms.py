from django.forms import ModelForm
from .models import Produtos
from django.forms import TextInput, Select, Textarea

class ProdutoForm(ModelForm):
    class Meta:
        model = Produtos
        fields = ['produto', 'cor', 'descricao']
        widgets = {
            'produto': TextInput(attrs={'class': 'input'}),
            'descricao': Textarea(attrs={'class': 'textarea'}),
            #'cor': Select(attrs={'class': 'select'})
        }

from django.shortcuts import render

from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from .models import Filmes, Generos

class FilmeList(ListView):
    model = Filmes
    template_name = 'filme_list.html'
    context_object_name = 'filmes'

class FilmeNew(CreateView):
    model = Filmes
    template_name = 'filme_new.html'
    fields = ['filme', 'genero', 'quantidade', 'preco']

class FilmeEdit(UpdateView):
    model = Filmes
    template_name = 'filme_edit.html'
    fields = ['filme', 'genero', 'quantidade', 'preco']

class FilmeDelete(DeleteView):
    model = Filmes
    template_name = 'filme_delete.html'
    success_url = reverse_lazy('filme_list')

# Create your views here.

from django.urls import path
from . import views

urlpatterns = [
    path('filme/', views.FilmeList.as_view(), name='filme_list'),
    path('filme/novo/', views.FilmeNew.as_view(), name='filme_new'),
    path('filme/<int:pk>/', views.FilmeEdit.as_view(), name='filme_edit'),
    path('filme/<int:pk>/delete/', views.FilmeDelete.as_view(), name='filme_delete'),
]
from django.contrib import admin
from .models import Generos
from .models import Filmes


class PessoasAdmin(admin.ModelAdmin):
    list_display = ['filme', 'genero', 'quantidade', 'preco']
    ordering = ['-filme']
    search_fields = ['filme']
    list_filter = ['genero']
    list_editable = ['genero', 'quantidade', 'preco']

admin.site.register(Generos)
admin.site.register(Filmes, PessoasAdmin)
# Register your models here.

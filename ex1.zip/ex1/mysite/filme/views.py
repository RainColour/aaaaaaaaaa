from django.shortcuts import render
from .models import filmes

def index(request):
    f = filmes.objects.all()
    template_name = 'index.html'
    context = {
        'f': f
    }

    return render(request, template_name, context)

# Create your views here.

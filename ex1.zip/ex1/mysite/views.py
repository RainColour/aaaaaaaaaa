from django.http import HttpResponse

def index(request):
    nome = 'Nomes'
    return HttpResponse(f'''
        <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Aula2</title>
    </head>
    <body>
        <h1>{nome}</h1>
    </body>
    </html>
    ''')